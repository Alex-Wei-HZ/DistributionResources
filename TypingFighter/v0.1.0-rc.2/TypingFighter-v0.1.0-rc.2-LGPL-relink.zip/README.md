# Typing Fighter — LGPL 库源码与重链接

普通玩家无需本包。它提供 Arduino ESP32 LGPL-2.1 库的对应源码、应用对象和重链接工具，支持接收者修改库并用于自身使用。完整许可及第三方声明在 `LICENSES/`。应用部分沿用所附 MIT 许可。

`framework/` 包含 Arduino 2.0.17 的 ESP32 核心、SPI、Wire、FS、SD、variant 源码及本版 ESP32-S3 SDK 输入；SDK 使用 `qio_qspi` 配置。`project/` 仅提供重链接需要的对象，没有游戏源码、调试数据或本机路径。对象仍含链接所需符号和机器码。本包不限制 LGPL 授予的修改及为调试这些修改而逆向的权利。

## 工具与重链接

使用 Python 3.10+、esptool 4.5.1 和 Espressif GCC 8.4.0 / esp-2021r2-patch5 的 ESP32-S3 工具链。编译器不随包提供，可使用现有 PlatformIO 工具链；对应元数据在 `TOOLCHAIN.json`。工具来源：[Espressif crosstool-NG](https://github.com/espressif/crosstool-NG/releases/tag/esp-2021r2-patch5)。不自动联网或安装依赖。

解压后在本目录运行，将路径替换成自己的安装位置：

```sh
python3 tools/verify.py
python3 relink.py --toolchain /path/to/toolchain-xtensa-esp32s3 --esptool /path/to/esptool.py --expect-release
```

输出为 `project/.pio/build/typing_fighter_adv_release/firmware.bin`，应与本清理版本的 app 镜像相同。清理过程移除了调试信息、非必要符号和同长度的本机路径字符串，保留重定位和链接所需符号；`privacy.py` 记录实际处理方法。`--expect-release` 对应当前版本，不能用于已修改库的构建。

## 修改 LGPL 库

修改 `framework/cores/esp32/` 或 `framework/libraries/` 后：

```sh
python3 relink.py --toolchain /path/to/toolchain-xtensa-esp32s3 --esptool /path/to/esptool.py --rebuild-libraries
```

脚本重编译 53 个翻译单元、更新五个 Arduino 库并链接。使用 `-g0` 和路径映射，输出仍经过调试及本机路径清理。新增源文件需在 `RELINK.json` 添加对应编译项；修改须与调用方对象 ABI 兼容。SDK 已移除未使用的其他内存配置、SDK bootloader 文件，以及上游 Mbed TLS 的公共测试证书对象；这些材料不参与本游戏链接。上游版权与许可证保持原样。

输出是 **app-only** 镜像，仅适用于相同已安装分区布局，写入地址 `0x10000`。不能从 `0x0000` 烧录。正常用户通过 M5Burner 安装完整固件；本脚本仅编译和校验，不访问设备。修改后的镜像没有沿用原镜像的真机验收结论。

发行方应将该版本重链接材料及许可与固件配套提供。已验证原始清理对象可在不同目录复现同一 app 镜像，库源码也可重新编译并链接。清理不会使机器码无法逆向。
