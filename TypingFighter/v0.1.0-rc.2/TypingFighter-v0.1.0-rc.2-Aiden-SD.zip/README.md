# Typing Fighter — Aiden SD 语音安装 / SD voice installation

适用 Cardputer ADV / K132-ADV。先通过 M5Burner 安装匹配版本固件。使用 **FAT32 / MBR** microSD，预留至少 32 MB。包内已包含全部 512 词，无需 TTS 模型、账号或联网。

## 新卡

将本包的整个 `TFVOICE` 目录复制到卡根目录，应有 `TFVOICE/ACTIVE.A`、`TFVOICE/PKG00001/MANIFEST.JL` 和 `TFVOICE/PKG00001/WAV/`。不要额外套一层 ZIP 名称目录。

## 已有 TFVOICE 的卡

使用 Python 3.10+，在解压目录运行（Windows 用 `py -3` 替换 `python3`）：

```sh
python3 tools/verify.py
python3 tools/install_aiden.py /Volumes/CARDPUTER
python3 tools/install_aiden.py /Volumes/CARDPUTER --verify-only
# Windows: py -3 tools/install_aiden.py E:/
```

将路径替换成自己的 SD 卡位置。安装器验证 512 词、保留旧包并激活 Aiden；相同内容重复安装不会新增包，支持 macOS 元数据文件。完成后安全弹出卡，关机、插卡再开机。

Enter 确认；直接使用方向标识键 `;`、`,`、`.`、`/`；`p` 暂停，`r` 重开。无声音时检查静音、音量和卡根目录结构，再运行 `--verify-only`。仅刷固件不会更新语音。烧录后若停在下载模式，松开 G0、短按 Reset。

模型版本、参数、来源和许可保留在 `TFVOICE/PKG00001/`。所有文件已自动检查，未逐条人工审听。工具按 `LICENSE-MIT.txt` 分发。

## English

Use a FAT32/MBR SD card with at least 32 MB free. For a fresh card, copy the complete `TFVOICE` folder to the card root. For a card with existing packages, run the Python commands above from this extracted directory, using your mounted card path. The installer retains old packages and avoids duplicate installs. Safely eject, power off, insert the card and restart.

Enter confirms, arrow-marked keys navigate, `p` pauses and `r` restarts. Check mute/volume, card-root paths and `--verify-only` if silent. No account, TTS model or network connection is required. Flashing firmware does not update SD voices.
