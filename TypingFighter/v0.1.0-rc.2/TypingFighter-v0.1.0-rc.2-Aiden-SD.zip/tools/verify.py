#!/usr/bin/env python3
"""Verify a local distribution without installing dependencies or using the network."""
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def verify(root=ROOT):
    count = 0
    for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        original = root / name
        path = original.resolve()
        if not path.is_relative_to(root.resolve()) or original.is_symlink():
            raise ValueError(f"Unsafe checksum path: {name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f"Checksum mismatch: {name}")
        count += 1
    return count


if __name__ == "__main__":
    print(f"OK: {verify()} distribution files verified")
