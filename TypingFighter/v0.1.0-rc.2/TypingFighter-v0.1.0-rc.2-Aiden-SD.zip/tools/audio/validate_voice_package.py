#!/usr/bin/env python3
"""Validate a Typing Fighter SD voice package directory."""

from __future__ import annotations

import argparse
import binascii
import datetime
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import wave

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SOURCE = ROOT.parent / "TFVOICE/PKG00001/PROMPTS.JSN"
CONTENT_SET_ID = "tf-en-default-v1"
REQUIRED_KEYS_SHA256 = (
    "e6a5c0377d3edb7d1f22408ec06d78617d388f58c23adad5ba28d7d8e2d38988"
)
SCHEMA_MAJOR = 1
FIRMWARE_API = 1
REQUIRED_COUNT = 512
MAX_ENTRY_COUNT = 544
MAX_MANIFEST_BYTES = 1024 * 1024
MAX_MANIFEST_LINE_BYTES = 2 * 1024
MAX_WAV_BYTES = 32 * 1024
MAX_WAV_MS = 3000
MAX_PACKAGE_WAV_BYTES = 32 * 1024 * 1024
SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2
CHANNELS = 1
PACKAGE_MODES = ("private-dev", "redistributable")
PRIVATE_DEV_REVIEW_STATUS = "private-dev-approved"
REDISTRIBUTABLE_REVIEW_STATUS = "published"
PKG_RE = re.compile(r"PKG[0-9]{5}\Z")
VOICE_KEY_RE = re.compile(r"en[0-9]{6}\Z")
FAT_COMPONENT_RE = re.compile(r"[A-Z0-9_]{1,8}(?:\.[A-Z0-9_]{1,3})?\Z")
SHA256_RE = re.compile(r"[0-9a-fA-F]{64}\Z")
PROMPT_TEXT_RE = re.compile(r"[A-Za-z]+(?:[ '-][A-Za-z]+)*\Z")
ZERO_SHA256 = "0" * 64


class PackageError(Exception):
    pass


def stable_voice_key(text: str) -> str:
    value = 2166136261
    for byte in text.encode("utf-8"):
        value ^= byte
        value = (value * 16777619) & 0xFFFFFFFF
    return f"en{value % 1_000_000:06d}"


def expected_prompts(source: Path = DEFAULT_SOURCE) -> dict[str, str]:
    if source.suffix.lower() in (".json", ".jsn"):
        mapping = json.loads(source.read_text(encoding="utf-8"))
        if (not isinstance(mapping, dict) or len(mapping) != REQUIRED_COUNT
                or any(not isinstance(text, str) or key != stable_voice_key(text)
                       for key, text in mapping.items())):
            raise PackageError("frozen prompt JSON has invalid keys, text or count")
        if any(not PROMPT_TEXT_RE.fullmatch(text) for text in mapping.values()):
            raise PackageError("frozen prompt JSON has invalid ASCII word text")
        return mapping
    raise PackageError("standalone installer requires frozen JSON prompts")


def required_keys_sha256(mapping: dict[str, str]) -> str:
    digest = hashlib.sha256()
    for key in sorted(mapping):
        digest.update(key.encode("utf-8"))
        digest.update(b"\0")
        digest.update(mapping[key].encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def record_crc_ok(text: str) -> bool:
    stripped = text.rstrip("\r\n")
    prefix, sep, crc_text = stripped.rpartition("|")
    if not sep or not re.fullmatch(r"[0-9A-Fa-f]{8}", crc_text):
        return False
    body = (prefix + "|").encode("ascii")
    return f"{binascii.crc32(body) & 0xFFFFFFFF:08X}" == crc_text.upper()


def parse_active(path: Path) -> dict | None:
    if not path.exists():
        return None
    text = path.read_text(encoding="ascii")
    if not record_crc_ok(text):
        return None
    fields = text.rstrip("\r\n").rsplit("|", 1)[0].split("|")
    if len(fields) != 5 or fields[0] != "TFVA1" or fields[1] != str(SCHEMA_MAJOR):
        return None
    if not PKG_RE.fullmatch(fields[3]) or not SHA256_RE.fullmatch(fields[4]):
        return None
    return {"sequence": int(fields[2]), "package_dir": fields[3], "manifest_sha256": fields[4].lower()}


def parse_commit(path: Path) -> dict:
    text = path.read_text(encoding="ascii")
    if not record_crc_ok(text):
        raise PackageError(f"{path}: bad COMMIT.OK CRC")
    fields = text.rstrip("\r\n").rsplit("|", 1)[0].split("|")
    if len(fields) != 7 or fields[0] != "TFVC1" or fields[1] != str(SCHEMA_MAJOR):
        raise PackageError(f"{path}: invalid COMMIT.OK fields")
    if not SHA256_RE.fullmatch(fields[4]):
        raise PackageError(f"{path}: invalid manifest hash")
    return {
        "package_id": fields[2],
        "package_version": fields[3],
        "manifest_sha256": fields[4].lower(),
        "file_count": int(fields[5]),
        "total_bytes": int(fields[6]),
    }


def derived_wav_path(key: str) -> Path:
    if not VOICE_KEY_RE.fullmatch(key):
        raise PackageError(f"{key}: invalid voice key")
    suffix = key[2:]
    return Path("WAV") / suffix[:2] / f"EN{suffix}.WAV"


def check_fat_path(relative: Path) -> None:
    for part in relative.parts:
        if part in ("", ".", "..") or "/" in part or "\\" in part:
            raise PackageError(f"{relative}: unsafe path component")
        if not FAT_COMPONENT_RE.fullmatch(part):
            raise PackageError(f"{relative}: not FAT 8.3 uppercase ASCII")


def load_manifest(path: Path) -> tuple[dict, list[dict]]:
    if path.stat().st_size > MAX_MANIFEST_BYTES:
        raise PackageError(f"{path}: manifest exceeds 1 MiB")
    package = None
    entries = []
    with path.open("r", encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            encoded_len = len(line.encode("utf-8"))
            if encoded_len > MAX_MANIFEST_LINE_BYTES:
                raise PackageError(f"{path}:{number}: line exceeds 2 KiB")
            record = json.loads(line)
            record_type = record.get("recordType")
            if number == 1:
                if record_type != "package":
                    raise PackageError(f"{path}: first record is not package")
                package = record
            elif record_type == "entry":
                entries.append(record)
            else:
                raise PackageError(f"{path}:{number}: invalid recordType")
    if package is None:
        raise PackageError(f"{path}: missing package record")
    return package, entries


def canonical_manifest_sha256(package: dict, entries: list[dict]) -> str:
    canonical_package = dict(package)
    canonical_package["manifestSha256"] = ZERO_SHA256
    lines = [json.dumps(canonical_package, ensure_ascii=False, sort_keys=True, separators=(",", ":"))]
    lines += [
        json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        for entry in entries
    ]
    return hashlib.sha256(("\n".join(lines) + "\n").encode("utf-8")).hexdigest()


def check_package_record(package: dict, expected_hash: str) -> None:
    checks = {
        "schemaMajor": SCHEMA_MAJOR,
        "contentSetId": CONTENT_SET_ID,
        "requiredKeysSha256": REQUIRED_KEYS_SHA256,
        "noticeFile": "NOTICE.TXT",
        "audioFormat": "wav-pcm-16000-16-1",
    }
    for field, expected in checks.items():
        if package.get(field) != expected:
            raise PackageError(f"package.{field}: expected {expected!r}")
    if package.get("schemaMinor", 0) > 0:
        raise PackageError("package.schemaMinor: unsupported")
    if not (package.get("firmwareApiMin") <= FIRMWARE_API <= package.get("firmwareApiMax")):
        raise PackageError("package firmware API range does not include firmware")
    if package.get("entryCount") > MAX_ENTRY_COUNT:
        raise PackageError("package.entryCount exceeds max")
    if package.get("requiredCount") != REQUIRED_COUNT:
        raise PackageError("package.requiredCount is not 512")
    if package.get("totalBytes", 0) > MAX_PACKAGE_WAV_BYTES:
        raise PackageError("package.totalBytes exceeds max")
    if package.get("manifestSha256", "").lower() != expected_hash.lower():
        raise PackageError("package manifest hash does not match active/commit")
    if package.get("packageMode") not in PACKAGE_MODES:
        raise PackageError("package.packageMode: expected private-dev or redistributable")
    if package.get("packageMode") == "private-dev" and "private" not in package.get("licensePolicy", ""):
        raise PackageError("package.licensePolicy: private-dev package must be marked private")
    for field in ("packageId", "packageVersion", "locale", "voiceSetId", "licensePolicy", "packageMode", "createdAt", "toolchain"):
        if not package.get(field):
            raise PackageError(f"package.{field}: missing")


def check_wav(path: Path, expected_bytes: int, expected_sha256: str, duration_ms: int) -> None:
    if not path.exists():
        raise PackageError(f"{path}: missing WAV")
    if path.stat().st_size != expected_bytes:
        raise PackageError(f"{path}: byte size mismatch")
    if expected_bytes > MAX_WAV_BYTES:
        raise PackageError(f"{path}: exceeds 32 KiB")
    if sha256_file(path) != expected_sha256.lower():
        raise PackageError(f"{path}: SHA-256 mismatch")
    with wave.open(str(path), "rb") as wav:
        if wav.getnchannels() != CHANNELS or wav.getsampwidth() != SAMPLE_WIDTH or wav.getframerate() != SAMPLE_RATE:
            raise PackageError(f"{path}: unsupported WAV format")
        actual_ms = round(wav.getnframes() * 1000 / wav.getframerate())
        if actual_ms > MAX_WAV_MS or duration_ms > MAX_WAV_MS:
            raise PackageError(f"{path}: duration exceeds max")


def expected_review_status(package_mode: str) -> str:
    if package_mode == "private-dev":
        return PRIVATE_DEV_REVIEW_STATUS
    return REDISTRIBUTABLE_REVIEW_STATUS


def check_notice(path: Path, package_mode: str) -> None:
    if not path.is_file():
        raise PackageError("NOTICE.TXT missing")
    text = path.read_text(encoding="utf-8")
    if package_mode == "private-dev":
        folded = text.lower()
        required = ("private development package", "do not upload", "do not redistribute")
        for needle in required:
            if needle not in folded:
                raise PackageError(f"NOTICE.TXT missing private-dev restriction: {needle}")


def check_entries(
    package_root: Path,
    entries: list[dict],
    expected: dict[str, str],
    package_mode: str,
    audio_format: str = "wav-pcm-16000-16-1",
) -> int:
    seen = {}
    total = 0
    for entry in entries:
        key = entry.get("voiceKey", "")
        if key in seen:
            raise PackageError(f"{key}: duplicate entry")
        seen[key] = entry
        if key not in expected:
            raise PackageError(f"{key}: not in firmware required set")
        if entry.get("exactText") != expected[key]:
            raise PackageError(f"{key}: exactText mismatch")
        if entry.get("required") is not True:
            raise PackageError(f"{key}: required must be true")
        for field in (
            "locale", "audioFormat", "voiceId", "modelId", "generator", "toolVersion",
            "sourceType", "sourceRevision", "author", "licenseId",
            "licenseUrl", "attribution", "inputSha256", "canonicalSha256",
            "fileSha256", "reviewStatus", "normalization",
        ):
            if not entry.get(field):
                raise PackageError(f"{key}: missing {field}")
        # Runtime entries inherit their mode from the package record. The
        # firmware entry schema does not include a packageMode string field.
        # If an external manifest repeats the field, it must still agree.
        if entry.get("packageMode", package_mode) != package_mode:
            raise PackageError(f"{key}: packageMode does not match package")
        if entry.get("audioFormat") != audio_format:
            raise PackageError(f"{key}: audioFormat does not match package")
        review_status = expected_review_status(package_mode)
        if entry.get("reviewStatus") != review_status:
            raise PackageError(f"{key}: reviewStatus is not {review_status}")
        if package_mode == "private-dev":
            if "private" not in entry.get("licenseId", "").lower() and "private" not in entry.get("attribution", "").lower():
                raise PackageError(f"{key}: private-dev restriction missing")
        for hash_field in ("inputSha256", "canonicalSha256", "fileSha256"):
            if not SHA256_RE.fullmatch(entry.get(hash_field, "")):
                raise PackageError(f"{key}: invalid {hash_field}")
        relative = derived_wav_path(key)
        check_fat_path(relative)
        check_wav(package_root / relative, entry["bytes"], entry["fileSha256"], entry["durationMs"])
        total += entry["bytes"]
    missing = sorted(set(expected) - set(seen))
    if missing:
        raise PackageError(f"{missing[0]}: missing required entry")
    return total


def is_macos_metadata(path: Path) -> bool:
    """Recognize Finder metadata without hiding arbitrary invalid files.

    macOS creates AppleDouble sidecars on FAT even for content-only writes.
    The firmware opens manifest-derived paths, so these files are irrelevant
    to playback. Never follow symlinks or ignore directories with these names.
    """
    if path.is_symlink() or not path.is_file():
        return False
    if path.name == ".DS_Store":
        return True
    if path.name.startswith("._"):
        with path.open("rb") as stream:
            header = stream.read(26)
        return (len(header) == 26 and header[:4] == b"\x00\x05\x16\x07"
                and header[4:8] in (b"\x00\x01\x00\x00", b"\x00\x02\x00\x00"))
    return False


def check_fat_conflicts(root: Path) -> None:
    seen = {}
    for path in root.rglob("*"):
        if is_macos_metadata(path):
            continue
        if path.is_symlink():
            raise PackageError(f"{path}: symlinks are not supported")
        relative = path.relative_to(root)
        folded = tuple(part.upper() for part in relative.parts)
        if folded in seen and seen[folded] != relative:
            raise PackageError(f"FAT case conflict: {seen[folded]} vs {relative}")
        seen[folded] = relative
        check_fat_path(relative)


def validate_package(sd_root: Path, source: Path = DEFAULT_SOURCE) -> dict:
    voice_root = sd_root / "TFVOICE"
    if not voice_root.is_dir():
        raise PackageError(f"{voice_root}: missing voice root")
    expected = expected_prompts(source)
    if required_keys_sha256(expected) != REQUIRED_KEYS_SHA256:
        raise PackageError("firmware required key hash drifted")
    active_records = [parse_active(voice_root / "ACTIVE.A"), parse_active(voice_root / "ACTIVE.B")]
    active_records = [record for record in active_records if record is not None]
    if not active_records:
        raise PackageError("no valid ACTIVE.A/B record")
    active = max(active_records, key=lambda item: item["sequence"])
    package_root = voice_root / active["package_dir"]
    if not package_root.is_dir():
        raise PackageError(f"{package_root}: missing active package")
    check_fat_conflicts(voice_root)
    commit = parse_commit(package_root / "COMMIT.OK")
    if commit["manifest_sha256"] != active["manifest_sha256"]:
        raise PackageError("commit manifest hash does not match active")
    package, entries = load_manifest(package_root / "MANIFEST.JL")
    check_package_record(package, active["manifest_sha256"])
    check_notice(package_root / "NOTICE.TXT", package["packageMode"])
    if canonical_manifest_sha256(package, entries) != active["manifest_sha256"]:
        raise PackageError("manifest canonical SHA-256 mismatch")
    if len(entries) != REQUIRED_COUNT:
        raise PackageError(f"manifest entry count {len(entries)} is not 512")
    total = check_entries(
        package_root, entries, expected, package["packageMode"], package["audioFormat"]
    )
    if total != package["totalBytes"] or total != commit["total_bytes"]:
        raise PackageError("total WAV bytes mismatch")
    if commit["file_count"] < REQUIRED_COUNT:
        raise PackageError("commit fileCount is below required count")
    return {
        "package": active["package_dir"],
        "entries": len(entries),
        "required": REQUIRED_COUNT,
        "total_bytes": total,
        "manifest_sha256": active["manifest_sha256"],
        "package_mode": package["packageMode"],
        "coverage": f"{len(entries)}/{REQUIRED_COUNT}",
        "content_set_id": package["contentSetId"],
        "required_keys_sha256": package["requiredKeysSha256"],
        "audio_format": package["audioFormat"],
        "notice_file": package["noticeFile"],
    }


def write_report(path: Path, summary: dict, sd_root: Path) -> None:
    report = {
        "recordType": "voicePackageValidationReport",
        "toolchain": "typing-fighter-voice-validator/0.1",
        "createdAt": datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat(),
        "sdRoot": str(sd_root),
        "result": "pass",
        **summary,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sd_root", type=Path, help="directory whose top level contains TFVOICE")
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--json", action="store_true", help="print machine-readable summary")
    parser.add_argument("--report", type=Path, help="write a machine-readable validation report")
    args = parser.parse_args(argv)
    try:
        summary = validate_package(args.sd_root, args.source)
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    else:
        print(
            f"OK: {summary['package']} {summary['entries']}/{summary['required']} "
            f"{summary['total_bytes']} bytes mode={summary['package_mode']}"
        )
    if args.report:
        write_report(args.report, summary, args.sd_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
