#!/usr/bin/env python3
"""Install and activate a validated Typing Fighter voice package on an SD root."""

from __future__ import annotations

import argparse
import binascii
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

import validate_voice_package

DEFAULT_PACKAGE = Path(__file__).resolve().parent / "package" / "PKG-SOURCE"


def crc_record(body: str) -> str:
    return f"{body}{binascii.crc32(body.encode('ascii')) & 0xFFFFFFFF:08X}\n"


def write_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(
            "w", encoding="ascii", dir=path.parent, delete=False
        ) as stream:
            temp = Path(stream.name)
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        temp.replace(path)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def next_package_dir(voice_root: Path) -> str:
    for number in range(1, 100000):
        name = f"PKG{number:05d}"
        if not (voice_root / name).exists():
            return name
    raise validate_voice_package.PackageError("no free PKGnnnnn slot")


def validate_uncommitted_package(package_root: Path, source: Path) -> dict:
    expected = validate_voice_package.expected_prompts(source)
    if validate_voice_package.required_keys_sha256(expected) != validate_voice_package.REQUIRED_KEYS_SHA256:
        raise validate_voice_package.PackageError("firmware required key hash drifted")
    if (package_root / "COMMIT.OK").exists():
        raise validate_voice_package.PackageError("source package already contains COMMIT.OK")
    validate_voice_package.check_fat_conflicts(package_root)
    package, entries = validate_voice_package.load_manifest(package_root / "MANIFEST.JL")
    manifest_hash = validate_voice_package.canonical_manifest_sha256(package, entries)
    if package.get("manifestSha256", "").lower() != manifest_hash:
        raise validate_voice_package.PackageError("manifest canonical SHA-256 mismatch")
    validate_voice_package.check_package_record(package, manifest_hash)
    validate_voice_package.check_notice(package_root / "NOTICE.TXT", package["packageMode"])
    total = validate_voice_package.check_entries(
        package_root, entries, expected, package["packageMode"]
    )
    if total != package["totalBytes"]:
        raise validate_voice_package.PackageError("total WAV bytes mismatch")
    return {
        "manifest_hash": manifest_hash,
        "package_id": package["packageId"],
        "package_version": package["packageVersion"],
        "entry_count": len(entries),
        "total_bytes": total,
    }


def copy_uncommitted_package(source_package: Path, target_package: Path) -> None:
    if target_package.exists():
        raise validate_voice_package.PackageError(f"{target_package}: target exists")
    # copytree/copy2 also copy macOS xattrs. Copy only content; Finder may still
    # create its own sidecars, which the validator recognizes independently.
    target_package.mkdir()
    for path in sorted(source_package.rglob("*")):
        if validate_voice_package.is_macos_metadata(path):
            continue
        if path.is_symlink():
            raise validate_voice_package.PackageError(f"{path}: symlinks are not supported")
        if path.name in {"COMMIT.OK", "ACTIVE.A", "ACTIVE.B"}:
            continue
        target = target_package / path.relative_to(source_package)
        if path.is_dir():
            target.mkdir()
        elif path.is_file():
            shutil.copyfile(path, target)


def package_files_match(source_package: Path, installed_package: Path) -> bool:
    for path in source_package.rglob("*"):
        if path.is_file() and not validate_voice_package.is_macos_metadata(path):
            installed = installed_package / path.relative_to(source_package)
            if (not installed.is_file() or installed.is_symlink()
                    or validate_voice_package.sha256_file(path) != validate_voice_package.sha256_file(installed)):
                return False
    return True


def write_commit(package_root: Path, summary: dict) -> None:
    body = (
        f"TFVC1|1|{summary['package_id']}|{summary['package_version']}|"
        f"{summary['manifest_hash']}|{summary['entry_count']}|"
        f"{summary['total_bytes']}|"
    )
    write_atomic(package_root / "COMMIT.OK", crc_record(body))


def choose_active_slot(voice_root: Path) -> tuple[Path, int]:
    active_a = validate_voice_package.parse_active(voice_root / "ACTIVE.A")
    active_b = validate_voice_package.parse_active(voice_root / "ACTIVE.B")
    sequence_a = active_a["sequence"] if active_a else 0
    sequence_b = active_b["sequence"] if active_b else 0
    if sequence_a <= sequence_b:
        return voice_root / "ACTIVE.A", max(sequence_a, sequence_b) + 1
    return voice_root / "ACTIVE.B", sequence_a + 1


def install_package(source_package: Path, sd_root: Path, source: Path) -> dict:
    if not source_package.is_dir():
        raise validate_voice_package.PackageError(f"{source_package}: missing source package")
    # Reject a bad source before touching the SD card.
    source_summary = validate_uncommitted_package(source_package, source)
    voice_root = sd_root / "TFVOICE"
    voice_root.mkdir(parents=True, exist_ok=True)
    validate_voice_package.check_fat_conflicts(voice_root)
    try:
        installed = validate_voice_package.validate_package(sd_root, source)
    except (validate_voice_package.PackageError, OSError, ValueError):
        installed = None
    if (installed and installed["manifest_sha256"] == source_summary["manifest_hash"]
            and package_files_match(source_package, voice_root / installed["package"])):
        active_path, _ = max(
            ((path, validate_voice_package.parse_active(path)) for path in
             (voice_root / "ACTIVE.A", voice_root / "ACTIVE.B")),
            key=lambda item: item[1]["sequence"] if item[1] else -1,
        )
        active = validate_voice_package.parse_active(active_path)
        return {"package": installed["package"], "active": active_path.name,
                "sequence": active["sequence"], "status": "already-installed", **source_summary}
    package_dir = next_package_dir(voice_root)
    target_package = voice_root / package_dir
    active_path = None
    previous_active = None
    activation_attempted = False
    try:
        copy_uncommitted_package(source_package, target_package)
        validate_voice_package.check_fat_conflicts(voice_root)
        summary = validate_uncommitted_package(target_package, source)
        if not package_files_match(source_package, target_package):
            raise validate_voice_package.PackageError("copied package file checksum mismatch")
        write_commit(target_package, summary)
        active_path, sequence = choose_active_slot(voice_root)
        previous_active = active_path.read_text(encoding="ascii") if active_path.exists() else None
        active_body = f"TFVA1|1|{sequence}|{package_dir}|{summary['manifest_hash']}|"
        activation_attempted = True
        write_atomic(active_path, crc_record(active_body))
        validate_voice_package.validate_package(sd_root, source)
    except Exception:
        if activation_attempted:
            if previous_active is None:
                active_path.unlink(missing_ok=True)
            else:
                write_atomic(active_path, previous_active)
        shutil.rmtree(target_package, ignore_errors=True)
        raise
    return {
        "package": package_dir,
        "active": active_path.name,
        "sequence": sequence,
        "status": "installed",
        **summary,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_package", type=Path, nargs="?", default=DEFAULT_PACKAGE,
                        help="uncommitted source package; defaults to the Git-tracked Aiden package")
    parser.add_argument("sd_root", type=Path, help="SD root to receive TFVOICE")
    parser.add_argument("--source", type=Path, default=validate_voice_package.DEFAULT_SOURCE)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        summary = install_package(args.source_package, args.sd_root, args.source)
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    else:
        print(f"OK: {summary['status']} {summary['package_id']} {summary['package']} "
              f"via {summary['active']} seq {summary['sequence']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
