#!/usr/bin/env python3
"""Install the enclosed TFVOICE tree safely on an existing FAT32 SD card."""
import argparse
import json
from pathlib import Path
import sys
import tempfile
sys.dont_write_bytecode = True

from verify import ROOT, verify
sys.path.insert(0, str(Path(__file__).resolve().parent / 'audio'))
import install_voice_package as installer
import validate_voice_package as validator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('sd_root', type=Path)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    if not args.sd_root.is_dir():
        raise ValueError('SD root must be an existing mounted directory')
    verify()
    source = ROOT / 'TFVOICE/PKG00001'
    prompts = source / 'PROMPTS.JSN'
    expected = validator.validate_package(ROOT, prompts)
    if args.verify_only:
        result = validator.validate_package(args.sd_root, prompts)
    else:
        with tempfile.TemporaryDirectory(prefix='voice-install-') as temporary:
            uncommitted = Path(temporary) / 'PKG-SOURCE'
            installer.copy_uncommitted_package(source, uncommitted)
            result = installer.install_package(uncommitted, args.sd_root, prompts)
    if result.get('manifest_hash', result.get('manifest_sha256')) != expected.get('manifest_hash', expected.get('manifest_sha256')):
        raise ValueError('SD card is not using this Aiden package')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
